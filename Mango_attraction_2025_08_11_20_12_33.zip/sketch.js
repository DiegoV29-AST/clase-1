var d;

function setup() {
  createCanvas(windowWidth, windowHeight);
background(212,0,60);
}

function draw() {
  d = random(10,60);
  fill(255,random(55,200))
  ellipse(mouseX,mouseY,d,d);
}